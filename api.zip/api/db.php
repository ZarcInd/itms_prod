<?php
// db.php - Database connection
$host = "localhost";
$db   = "ohm_primeedg";
$user = "ohm_primeedg";
$pass = "oq7aFmbxA2OEJpkt";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed"]);
    exit;
}
?>