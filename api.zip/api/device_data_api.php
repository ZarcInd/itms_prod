<?php
header("Content-Type: application/json");
require "db.php";

// --- Authentication ---
$headers = getallheaders();
$apiKey = isset($headers['X-API-KEY']) ? $headers['X-API-KEY'] : '';

$validApiKey = "Xn9#tP6@R3q!mW7dF2^vL8hJ0zK5*oY4sUeZbDaTiBp"; // store in env/config ideally
if ($apiKey !== $validApiKey) {
    http_response_code(401);
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

// --- Input Validation ---
$date     = isset($_GET['date']) ? $_GET['date'] : null;
$firmware = isset($_GET['firmware_version']) ? $_GET['firmware_version'] : null;
$device   = isset($_GET['device_id']) ? $_GET['device_id'] : null; // may be "all"
$limit    = isset($_GET['limit']) && $_GET['limit'] !== '' ? (int)$_GET['limit'] : null;
$offset   = isset($_GET['offset']) && $_GET['offset'] !== '' ? (int)$_GET['offset'] : 0;

if (!$date || !$firmware) {
    http_response_code(400);
    echo json_encode(["error" => "Missing required parameters (date, firmware_version)"]);
    exit;
}

// --- Build Query ---
$sql = "SELECT device_id, firmware_version, fleet_no, 	depo, device_status, total_packet, expected_packet, odo_meter, start_packet, last_packet,  time_stamp 
        FROM device_data 
        WHERE DATE(time_stamp) = :date 
        AND firmware_version = :firmware";

$params = [
    ":date" => $date,
    ":firmware" => $firmware
];

if ($device && strtolower($device) !== 'all') {
    $sql .= " AND device_id = :device";
    $params[":device"] = $device;
}

$sql .= " ORDER BY device_id ASC, time_stamp ASC";

// ✅ Add limit/offset only if user passed limit
if ($limit !== null) {
    $sql .= " LIMIT :limit OFFSET :offset";
}

$stmt = $pdo->prepare($sql);
$stmt->bindValue(':date', $date);
$stmt->bindValue(':firmware', $firmware);
if ($device && strtolower($device) !== 'all') {
    $stmt->bindValue(':device', $device);
}
if ($limit !== null) {
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
}

$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// --- Count Total (all rows, not distinct) ---
$countSql = "SELECT COUNT(*) FROM device_data 
             WHERE DATE(time_stamp) = :date 
             AND firmware_version = :firmware";
if ($device && strtolower($device) !== 'all') {
    $countSql .= " AND device_id = :device";
}

$countStmt = $pdo->prepare($countSql);
$countStmt->execute($params);
$totalRows = $countStmt->fetchColumn();

echo json_encode([
    "status" => "success",
    "total" => (int)$totalRows,
    "limit" => $limit ?? "all",
    "offset" => $limit !== null ? $offset : 0,
    "data" => $rows
]);
?>
