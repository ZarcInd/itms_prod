
<?php $__env->startSection('container'); ?>
<main class="main-content">
    <div class="container-fluid px-4">
    <h2 class="mb-4">Users</h2>
        <div class="card">
            <div class="card-header bg-primary-custom text-white d-flex justify-content-between align-items-center">
                <h4 class="mb-0" style="color: #775DA6;">Users</h4>
                <div>
                 <?php if($role === 'sub-admin' && (!isset($accesss['add']) || $accesss['add'] != '1')): ?>
                 
                  <?php else: ?>    
                <a href="<?php echo e(route('user.add')); ?>" class="btn btn-sm btn-light me-2" id="btn-exportcsv">
                     <i class="fas fa-plus"></i> Add User
                </a>
                <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped" id="user-table">
                        <thead class="table-header">
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>

    </div>

</main>

<script src="<?php echo e(asset('public/backend/js/user.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layouts/master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\chat_app\resources\views/admin/user/list.blade.php ENDPATH**/ ?>