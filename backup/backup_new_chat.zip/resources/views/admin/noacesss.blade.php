@extends('admin/layouts/master')
@section('container')
<main class="main-content">
    <div class="container-fluid px-4">
        <h2 class="mb-4">You Have No Access This Page</h2>
    </div>

</main>



</script>  
@endsection