
$(document).ready(function() {
    // Get DOM elements
    const $importBtn = $('#btn-import');
    const $csvFileInput = $('#csv-file-input');
    const $importStatusModal = $('#import-status-modal');
    const $progressBar = $('#import-progress-bar');
    const $importStatus = $('#import-status');
    const $importResults = $('#import-results');

    // Initialize Bootstrap modal
    const statusModal = new bootstrap.Modal($importStatusModal[0]);

    // When import button is clicked, trigger file input click
    $importBtn.on('click', function() {
        $csvFileInput.click();
    });

    // When a file is selected
    $csvFileInput.on('change', function(event) {
        const file = event.target.files[0];

        if (!file) {
            return; // No file selected
        }

        // Validate file is a CSV
        if (file.type !== 'text/csv' && !file.name.endsWith('.csv')) {
            alert('Please select a valid CSV file.');
            return;
        }

        // Reset the progress and status
        $progressBar.css('width', '0%').removeClass('bg-danger').addClass('bg-primary');
        $importStatus.text('Please wait while your CSV file is being processed...');
        $importResults.html('');

        // Create form data for the AJAX request
        const formData = new FormData();
        formData.append('csv_file', file);

        // Show the status modal
        statusModal.show();

        // Simulate progress (for better UX)
        let progress = 0;
        const progressInterval = setInterval(function() {
            if (progress < 90) {
                progress += 5;
                $progressBar.css('width', progress + '%');
            }
        }, 300);

        // Get the URL from the button's data-url attribute
        const dataUrl = $importBtn.data('url');
        // Send AJAX request to the server
        $.ajax({
            url: dataUrl,
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(data) {
                clearInterval(progressInterval);
            
                // Complete the progress bar
                $progressBar.css('width', '100%');
            
                // Display success message
                $importStatus.text('Import completed successfully!');
            
                // Display import results
                if (data.imported > 0) {
                    $importResults.append(`
                        <div class="alert alert-success">
                            <strong>Success!</strong> ${data.imported} vehicles imported successfully.
                        </div>
                    `);
                }
            
                if (data.skipped > 0) {
                    $importResults.append(`
                        <div class="alert alert-warning">
                            <strong>Notice:</strong> ${data.skipped} records were skipped.
                        </div>
                    `);
                }
            
                if (data.errors && data.errors.length > 0) {
                    let errorList = '<ul class="mb-0">';
                    data.errors.forEach(function(error) {
                        errorList += `<li>${error}</li>`;
                    });
                    errorList += '</ul>';
            
                    $importResults.append(`
                        <div class="alert alert-danger">
                            <strong>Errors:</strong> ${errorList}
                        </div>
                    `);
                }
            
                // Reset file input for future imports
                $csvFileInput.val('');
            
                // Optionally refresh the vehicles list if the function exists
                if (typeof refreshVehiclesList === 'function') {
                    refreshVehiclesList();
                }
            
                // Reload the DataTable after all results are processed
                $('#device-table').DataTable().ajax.reload(null, false);
            },
            error: function(jqXHR, textStatus, errorThrown) {
                clearInterval(progressInterval);
            
                // Display error
                $progressBar.css('width', '100%').removeClass('bg-primary').addClass('bg-danger');
            
                $importStatus.text('Error importing CSV file.');
                $importResults.html(`
                    <div class="alert alert-danger">
                        <strong>Error:</strong> ${errorThrown}
                    </div>
                `);
            
                // Reset file input
                $csvFileInput.val('');
            }
            
        });
    });
});

// Wait for DOM to be fully loaded


document.addEventListener('DOMContentLoaded', function () {
    // Get references to DOM elements
    const addVehicleBtn = document.getElementById('btn-add');
    const deviceModal = document.getElementById('device-modal');
    const closeBtn = deviceModal.querySelector('.btn-close');

    // Initialize Bootstrap modal
    const modal = new bootstrap.Modal(deviceModal);

    // Open modal when "Add Vehicle" button is clicked
    addVehicleBtn.addEventListener('click', function () {
        modal.show();
    });

    // Close modal when close button is clicked
    closeBtn.addEventListener('click', function () {
        modal.hide();
    });

    // Optional: Close modal when clicking outside the modal dialog
    deviceModal.addEventListener('click', function (event) {
        if (event.target === deviceModal) {
            modal.hide();
        }
    });
});

    
function formatDateTime(dateStr) {
    if (!dateStr) return '';
    // Split input format: "DD-MM-YYYY HH:mm:ss"
    const [datePart, timePart] = dateStr.split(' ');
    const [day, month, year] = datePart.split('-');
    const [hours, minutes] = timePart.split(':');
    return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}T${hours.padStart(2, '0')}:${minutes.padStart(2, '0')}`;
}



    // Fill modal inputs
    function devicedit(id, el) {
        const modal = $('#edit_device-modal');
        let status = $(el).data('status');
        // Fill modal inputs
        modal.find('#id').val($(el).data('id'));
        modal.find('#device_id').val($(el).data('device_id'));
        modal.find('#vehicle_no').val($(el).data('vehicle_no'));
        modal.find('#agency').val($(el).data('agency'));
        modal.find('#depot').val($(el).data('depot'));
        modal.find('#protocol').val($(el).data('protocol'));
        modal.find('#region_id').val($(el).data('region_id'));
        // Show modal
        modal.modal('show');
    }

            let deviceDataInterval = null;  // For clearing interval
          let deviceRefarshUrl = null;    // For storing refresh URL

          function deviceinf(deviceId, button) {
              const devicedata = button.dataset;

              // Store refresh URL (only once)
              deviceRefarshUrl = devicedata.refars_url;

              // Function to populate modal
              function populateDeviceModal(data) {
                  document.getElementById('modal-device_id_m').textContent = data.device_id;
                  document.getElementById('modal-vehicle_no_m').textContent = data.vehicle_no;
                  document.getElementById('modal-protocol_m').textContent = data.protocol;
                  document.getElementById('modal-lat_m').textContent = data.lat;
                  document.getElementById('modal-lon_m').textContent = data.lon;
                  document.getElementById('modal-time_in_packet_m').textContent = data.time_in_packt;
                  document.getElementById('modal-natwork_m').textContent = data.natwork;
                  document.getElementById('modal-packet_status_m').textContent = data.packet_status;
                  document.getElementById('modal-gps_signal_m').textContent = data.gps_signal;
              }

              // Initial population
              populateDeviceModal(devicedata);

              // Open modal
              const modalElement = document.getElementById('show_device-modal');
              const modal = new bootstrap.Modal(modalElement);
              modal.show();

              // After modal shown, start interval refresh
              modalElement.addEventListener('shown.bs.modal', function () {
                  // Start refreshing every 30 seconds
                  deviceDataInterval = setInterval(function () {
                      fetchDeviceData(function (newData) {
                          populateDeviceModal(newData);
                      });
                  }, 60000); // 30 sec
              }, { once: true });

              // Clear interval when modal hidden
              modalElement.addEventListener('hidden.bs.modal', function () {
                  if (deviceDataInterval) {
                      clearInterval(deviceDataInterval);
                      deviceDataInterval = null;
                  }
              });
          }

          // Fetch new device data from server
          function fetchDeviceData(callback) {
              if (!deviceRefarshUrl) {
                  console.error('Refresh URL is not set');
                  return;
              }

              fetch(deviceRefarshUrl)
                  .then(response => {
                      if (!response.ok) {
                          throw new Error('Network response was not ok');
                      }
                      return response.json();
                  })
                  .then(data => {
                      callback(data);
                  })
                  .catch(error => {
                      console.error('Error fetching device data:', error);
                  });
          }


    


$(document).ready(function() {
    $('.form_submit').on('submit', function(event){
        event.preventDefault();

        $('.submit_button').html('<i class="fa fa-spinner fa-spin"></i>').prop('disabled', true);

        var form_data = new FormData(this);
        var action_url = $(this).attr('action'); //  Get URL from form attribute

        $.ajax({
            headers: {
                'X-CSRF-TOKEN': "{{ csrf_token() }}"
            },
            type: "POST",
            url: action_url, // 👈 Use dynamic URL
            data: form_data,
            dataType: "json",
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                if (data.status == true) {
                    $('.submit_button').html('Submit').prop('disabled', false);
                    $('#ajax_message')
                        .addClass('alert-success')
                        .removeClass('alert-danger hidden')
                        .html('<li>' + data.message + '</li>');
                     // 👉 Close modal
                        $('#device-modal').modal('hide');
                        $('#edit_device-modal').modal('hide');
                        $('#add_form')[0].reset(); // 🔥 Clear form
                        // 👉 Refresh DataTable
                        $('#device-table').DataTable().ajax.reload(null, false); // false = stay on current page
                         alert(data.message);
                        
                    // Redirect on success
                } else {
                    $('#ajax_message')
                        .addClass('alert-danger')
                        .removeClass('alert-success hidden')
                        .html('<li>' + data.message + '</li>');
                        alert(data.message);
                }

                setTimeout(function() {
                    $('#ajax_message').addClass('hidden');
                }, 5000);

                $('.submit_button').html('Submit').prop('disabled', false);
            },
            error: function(data) {
                alert('Something went wrong. Please try again.');
                $('.submit_button').html('Submit').prop('disabled', false);
            }
        });
    });
});

function resetFormAndCheckboxes() {
    $('#add_form')[0].reset();
    $('input[type="checkbox"]').each(function () {
        $(this).prop('checked', false).val('No');
        const $valueDisplay = $(this).closest('.toggle-container').find('.toggle-value');
        $valueDisplay.text('No').removeClass('on').addClass('off');
    });
}

// Use this when needed
resetFormAndCheckboxes();

// CSV Download Handler
$(document).ready(function () {
    $('#btn-export').on('click', function (e) {
        e.preventDefault();

        const $btn = $(this);
        const originalHtml = $btn.html();
        $btn.html('<i class="fas fa-spinner fa-spin"></i> Exporting...');
        $btn.prop('disabled', true);

        // Use FormData to send form-style POST data
        const formData = new FormData();
        formData.append('packet_type', $('#packet_type').val());
        formData.append('fleet_number', $('#fleet_number').val());
        formData.append('device_number', $('#device_number').val());
        formData.append('date_filter', $('#date_filter').val());

        $.ajax({
            url: $btn.attr('href'),
            method: 'POST',
            data: formData,
            dataType: 'json',
            contentType: false,
            processData: false,
            cache: false,
            success: function (response) {
                console.log('Success:', response);
                showNotification('Export processed successfully!', 'success');
                // You can also display data like:
                // console.log(response.data);
            },
            error: function (xhr) {
                console.error('Export failed:', xhr.responseText);
                showNotification('Failed to process export. Please try again.', 'error');
            },
            complete: function () {
                $btn.html(originalHtml);
                $btn.prop('disabled', false);
            }
        });
    });

    function showNotification(message, type) {
        if (typeof toastr !== 'undefined') {
            toastr[type](message);
        } else {
            alert(message);
        }
    }
});

