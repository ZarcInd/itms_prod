<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('vehicles', function (Blueprint $table) {
            $table->id();
            $table->string('vehicle_no')->nullable();
            $table->string('vehicle_code')->nullable();
            $table->string('device_id')->nullable();
            $table->string('city')->nullable();
            $table->string('agency')->nullable();
            $table->string('operator')->nullable();
            $table->string('depot')->nullable();
            $table->string('vehicle_type')->nullable();
            $table->string('seating_capacity')->nullable();
            $table->string('region')->nullable();
            $table->string('etim_frequency')->nullable();
            $table->string('gst_on_ticket')->nullable();
            $table->string('surcharge_on_ticket')->nullable();
            $table->string('collection_on_etim')->nullable();
            $table->enum('status', ['0', '1'])->default('1');
            $table->string('gps_from_etim')->nullable();
            $table->string('forward_to_shuttl')->nullable();
            $table->string('service_category')->nullable();
            $table->string('fuel_type')->nullable();
            $table->string('dispatch_type')->nullable();
            $table->string('route_name')->nullable();
            $table->string('service_start_time')->nullable();
            $table->string('service_end_time')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('vehicles');
    }
};
