<?php
require_once __DIR__ . "/db.php";
require_once __DIR__ . "/xml.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $imei = $_POST["imei"] ?? null;
    
    if (empty($imei)) {
        throw new Exception("IMEI  is required", 1);
    }

    $imei = $imei ?? 0;

    // Note: Relying on DB foreign keys for integrity of data

    $data = [
        "imei" => $_POST["imei"] ?? $_POST["imei"] ?? "",
        "voip_username" => $_POST["voip_username"] ?? $_POST["voip_username"] ?? "",
        "voip_password" => $_POST["voip_password"] ?? $_POST["voip_password"] ?? "",
        "voip_url" => $_POST["voip_url"] ?? $_POST["voip_url"] ?? "",
        "speed_dial_1" => $_POST["speed_dial_1"] ?? $_POST["speed_dial_1"] ?? "",
        "speed_dial_2" => $_POST["speed_dial_2"] ?? $_POST["speed_dial_2"] ?? "",
        "speed_dial_3" => $_POST["speed_dial_3"] ?? $_POST["speed_dial_3"] ?? "",
        "speed_dial_4" => $_POST["speed_dial_4"] ?? $_POST["speed_dial_4"] ?? "",
        "speed_dial_5" => $_POST["speed_dial_5"] ?? $_POST["speed_dial_5"] ?? "",
        "speed_dial_6" => $_POST["speed_dial_6"] ?? $_POST["speed_dial_6"] ?? "",
    ];
    $res = update_data_ipdb($imei, $data);

    if ($res && $res['status']) {
        
        $dre =  deleteXml($imei);
        // $imeis = [$imei];
        // if ($group_id) {
        //     $imeis = get_imei_by_group($group_id);
        //     if ($imeis['status']) {
        //         $imeis = $imeis['data'];
        //     } else {
        //         $imeis = [];
        //     }
        // }
        // foreach ($imeis as $upd_imei) {
        //     deleteXml($upd_imei['imei']);
        // }
        echo json_encode(['status' => 'success', 'message' => 'IP Configuration saved successfully.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Save failed. ' . ($res['message'] ?? "")]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
}
